# TravelRadar V1.1

Improved MVP: a Reel is **never saved at the user's current location by default**.

Flow:
1. Paste Instagram Reel URL.
2. Enter the place/city mentioned or shown in the Reel.
3. TravelRadar geocodes the location using OpenStreetMap/Nominatim.
4. Review the detected location.
5. Confirm and save.
6. The saved pin appears at the detected location.

Note: automatic extraction of location directly from Instagram Reel content requires a backend/API and is intentionally not faked in V1.1.
